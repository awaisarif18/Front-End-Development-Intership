const userInput = document.querySelector("#userInput");
const submitButton = document.querySelector("#submitButton");
const form = document.querySelector("#form");
const list = document.querySelector("#list");
const arr = [];

let index = 0;

form.addEventListener("click", function (event) {
  event.preventDefault();
  addItem();
});

function addItem() {
  index++;
  const grocery = userInput.value;
  const dataObj = {};

  if (grocery.trim() !== "") {
    dataObj.task = grocery;
    dataObj.del = `<button class="removeButton">
        <i class="fa-solid fa-trash" style="color: #cf1717;"></i>
      </button>`;
    dataObj.edit = `<i id= 'editButton' class="fa-regular fa-pen-to-square"></i>`;

    dataObj.position = index;

    arr.push(dataObj);

    if (list.hasChildNodes()) {
      while (list.firstChild) {
        list.removeChild(list.firstChild);
      }
    }
    arr.forEach((obj) => {
      index = 0;
      const item = document.createElement("div");
      item.className = "listItem";
      item.id = "listItems";
      item.innerHTML = `${obj.task}  ${obj.del} ${obj.edit}`;
      list.appendChild(item);
      index++;

      const removeButton = item.querySelector(".removeButton");

      removeButton.style.border = "none";

      removeButton.addEventListener("click", function () {
        list.removeChild(item);
        arr.splice(obj.position, 1);
      });

      // const editButton = item.querySelector("#editButton");

      // editButton.addEventListener("click", () => {
      //   arr[obj.position].task = "harry";
      // });
    });

    userInput.value = "";
  }

  // const clearButton = document.createElement("button");
  // const x = document.createTextNode("Clear All Items");
  // clearButton.appendChild(x);
  // list.appendChild(clearButton);
  // clearButton.id = "clearButton";

  // clearButton.addEventListener("click", () => {
  //   while (list.firstChild) {
  //     list.removeChild(list.firstChild);
  //   }

  //   arr.splice(0, arr.length);
  // });
}

console.log(arr);
