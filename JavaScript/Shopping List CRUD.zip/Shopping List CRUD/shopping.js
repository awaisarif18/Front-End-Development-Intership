const userInput = document.querySelector("#userInput");
const submitButton = document.querySelector("#submitButton");
const form = document.querySelector("#form");
const list = document.querySelector("#list");

form.addEventListener("click", function (event) {
  event.preventDefault();
  addItem();
});

function addItem() {
  const grocery = userInput.value;

  if (grocery.trim() !== "") {
    const item = document.createElement("div");
    item.className = "listItem";
    item.innerHTML = `-${grocery}  <button class="removeButton"><i class="fa-solid fa-trash" style="color: #cf1717;"></i></button>`;
    list.appendChild(item);

    userInput.value = "";

    const removeButton = item.querySelector(".removeButton");

    removeButton.style.border = "none";

    removeButton.addEventListener("click", function () {
      list.removeChild(item);
    });
  }
}
